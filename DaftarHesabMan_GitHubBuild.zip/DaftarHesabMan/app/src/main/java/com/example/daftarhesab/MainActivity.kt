package com.example.daftarhesab

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.net.Uri
import androidx.core.content.FileProvider
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat
import java.util.Calendar
import java.util.Locale

data class Customer(val id: Long, val name: String, val balance: Long)
data class Entry(val id: Long, val customerId: Long, val type: String, val description: String, val amount: Long, val date: String)

class LedgerDb(ctx: Context) : SQLiteOpenHelper(ctx, "ledger.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL)")
        db.execSQL("""CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL,
            type TEXT NOT NULL, description TEXT NOT NULL, amount INTEGER NOT NULL, date TEXT NOT NULL)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addCustomer(name: String) {
        writableDatabase.execSQL("INSERT INTO customers(name) VALUES(?)", arrayOf(name.trim()))
    }
    fun customers(): List<Customer> {
        val out = mutableListOf<Customer>()
        val c = readableDatabase.rawQuery("""SELECT c.id,c.name,
            COALESCE(SUM(CASE WHEN e.type='sale' THEN e.amount ELSE -e.amount END),0)
            FROM customers c LEFT JOIN entries e ON e.customer_id=c.id GROUP BY c.id ORDER BY c.name COLLATE NOCASE""", null)
        c.use { while (it.moveToNext()) out.add(Customer(it.getLong(0), it.getString(1), it.getLong(2))) }
        return out
    }
    fun addEntry(customerId: Long, type: String, desc: String, amount: Long, date: String) {
        writableDatabase.execSQL("INSERT INTO entries(customer_id,type,description,amount,date) VALUES(?,?,?,?,?)",
            arrayOf(customerId, type, desc, amount, date))
    }
    fun entries(customerId: Long): List<Entry> {
        val out = mutableListOf<Entry>()
        val c = readableDatabase.rawQuery("SELECT id,customer_id,type,description,amount,date FROM entries WHERE customer_id=? ORDER BY id DESC",
            arrayOf(customerId.toString()))
        c.use { while (it.moveToNext()) out.add(Entry(it.getLong(0),it.getLong(1),it.getString(2),it.getString(3),it.getLong(4),it.getString(5))) }
        return out
    }
    fun deleteEntry(id: Long) { writableDatabase.delete("entries", "id=?", arrayOf(id.toString())) }
    fun exportJson(): String {
        val root = JSONObject()
        val cs = JSONArray()
        readableDatabase.rawQuery("SELECT id,name FROM customers ORDER BY id", null).use { c ->
            while (c.moveToNext()) cs.put(JSONObject().put("id",c.getLong(0)).put("name",c.getString(1)))
        }
        val es = JSONArray()
        readableDatabase.rawQuery("SELECT id,customer_id,type,description,amount,date FROM entries ORDER BY id", null).use { c ->
            while (c.moveToNext()) es.put(JSONObject().put("id",c.getLong(0)).put("customer_id",c.getLong(1))
                .put("type",c.getString(2)).put("description",c.getString(3)).put("amount",c.getLong(4)).put("date",c.getString(5)))
        }
        return root.put("format","daftarhesab-v1").put("customers",cs).put("entries",es).toString(2)
    }
    fun importJson(json: String) {
        val root = JSONObject(json)
        require(root.optString("format") == "daftarhesab-v1") { "فرمت فایل پشتیبان معتبر نیست" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("entries",null,null); db.delete("customers",null,null)
            val cs = root.getJSONArray("customers")
            for (i in 0 until cs.length()) {
                val o=cs.getJSONObject(i)
                db.execSQL("INSERT INTO customers(id,name) VALUES(?,?)", arrayOf(o.getLong("id"),o.getString("name")))
            }
            val es = root.getJSONArray("entries")
            for (i in 0 until es.length()) {
                val o=es.getJSONObject(i)
                db.execSQL("INSERT INTO entries(id,customer_id,type,description,amount,date) VALUES(?,?,?,?,?,?)",
                    arrayOf(o.getLong("id"),o.getLong("customer_id"),o.getString("type"),o.getString("description"),o.getLong("amount"),o.getString("date")))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
}

object Jalali {
    // Gregorian-to-Jalali conversion (Borkowski algorithm)
    fun today(): String {
        val c=Calendar.getInstance()
        val gY=c.get(Calendar.YEAR); val gM=c.get(Calendar.MONTH)+1; val gD=c.get(Calendar.DAY_OF_MONTH)
        val gdm= intArrayOf(0,31, if (isLeap(gY)) 29 else 28,31,30,31,30,31,31,30,31,30,31)
        var gy=gY-1600; var gm=gM-1; var gd=gD-1
        var gDayNo=365*gy+(gy+3)/4-(gy+99)/100+(gy+399)/400
        for(i in 0 until gm) gDayNo+=gdm[i+1]
        gDayNo+=gd
        var jDayNo=gDayNo-79
        val jNp=jDayNo/12053
        jDayNo%=12053
        var jy=979+33*jNp+4*(jDayNo/1461)
        jDayNo%=1461
        if(jDayNo>=366){ jy+=(jDayNo-1)/365; jDayNo=(jDayNo-1)%365 }
        val jm: Int
        val jd: Int
        if(jDayNo<186){ jm=1+(jDayNo/31); jd=1+(jDayNo%31) }
        else { jm=7+((jDayNo-186)/30); jd=1+((jDayNo-186)%30) }
        return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)
    }
    private fun isLeap(y:Int)= y%4==0 && (y%100!=0 || y%400==0)
}

class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private lateinit var root: LinearLayout
    private var currentCustomer: Customer? = null
    private val money = DecimalFormat("#,###")
    private val green = 0xFF176B5B.toInt()
    private val dark = 0xFF18312C.toInt()
    private val muted = 0xFF66736F.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db=LedgerDb(this)
        showHome()
    }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=16f,bold:Boolean=false,color:Int=dark): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(typeface,Typeface.BOLD); gravity=Gravity.RIGHT }
    private fun button(s:String, action:()->Unit): Button = Button(this).apply {
        text=s; isAllCaps=false; setTextColor(-1); setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
        setOnClickListener { action() }
    }
    private fun page(title:String): LinearLayout {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(12)); layoutDirection=View.LAYOUT_DIRECTION_RTL; setBackgroundColor(0xFFF5F7F6.toInt()) }
        val header=text(title,23f,true,green); header.setPadding(0,0,0,dp(16)); root.addView(header)
        val scroll=ScrollView(this)
        val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL }
        scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        return content
    }
    private fun showHome() {
        currentCustomer=null
        val content=page("دفتر حساب من")
        content.addView(text("حساب مشتری‌ها",17f,true))
        content.addView(button("+ افزودن مشتری جدید"){ addCustomerDialog() })
        content.addView(button("پشتیبان‌گیری / بازیابی"){ backupMenu() })
        val customers=db.customers()
        if(customers.isEmpty()) content.addView(text("هنوز مشتری‌ای ثبت نشده است. از دکمه بالا شروع کن.",15f,false,muted).apply { setPadding(0,dp(24),0,0) })
        customers.forEach { c ->
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(10),dp(12),dp(10)); setBackgroundColor(-1); layoutDirection=View.LAYOUT_DIRECTION_RTL }
            val bal=if(c.balance>0) "بدهکار: ${money.format(c.balance)} تومان" else if(c.balance<0) "بستانکار: ${money.format(-c.balance)} تومان" else "تسویه"
            card.addView(text(c.name,18f,true))
            card.addView(text(bal,14f,false,if(c.balance>0) 0xFFB23A48.toInt() else green))
            card.setOnClickListener { showCustomer(c) }
            val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(10),0,0); content.addView(card,lp)
        }
    }
    private fun addCustomerDialog() {
        val input=EditText(this).apply { hint="نام مشتری"; gravity=Gravity.RIGHT; textDirection=View.TEXT_DIRECTION_RTL }
        AlertDialog.Builder(this).setTitle("مشتری جدید").setView(input)
            .setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_-> val n=input.text.toString().trim()
                if(n.isNotEmpty()){ db.addCustomer(n); showHome() } else toast("نام مشتری را وارد کن") }.show()
    }
    private fun showCustomer(c:Customer) {
        currentCustomer=c
        val content=page(c.name)
        val balance=db.customers().firstOrNull{it.id==c.id}?.balance ?: 0L
        val balanceText=if(balance>0) "بدهی مشتری: ${money.format(balance)} تومان" else if(balance<0) "طلب مشتری: ${money.format(-balance)} تومان" else "حساب تسویه است"
        content.addView(text(balanceText,19f,true,if(balance>0) 0xFFB23A48.toInt() else green))
        content.addView(button("+ ثبت کالا / بدهکاری"){ entryDialog(c,"sale") })
        content.addView(button("+ ثبت دریافت وجه"){ entryDialog(c,"payment") })
        content.addView(button("بازگشت به فهرست مشتری‌ها"){ showHome() })
        content.addView(text("گردش حساب",17f,true).apply { setPadding(0,dp(16),0,dp(4)) })
        db.entries(c.id).forEach { e ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(10),dp(9),dp(10),dp(9)); setBackgroundColor(-1); layoutDirection=View.LAYOUT_DIRECTION_RTL }
            val label=if(e.type=="sale") "خرید: ${e.description}" else "پرداخت: ${e.description.ifBlank { "دریافت وجه" }}"
            row.addView(text(label,16f,true))
            row.addView(text("${e.date}     ${money.format(e.amount)} تومان",14f,false,muted))
            row.setOnLongClickListener {
                AlertDialog.Builder(this).setMessage("این تراکنش حذف شود؟").setNegativeButton("انصراف",null)
                    .setPositiveButton("حذف"){_,_-> db.deleteEntry(e.id); showCustomer(c) }.show(); true
            }
            val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(7),0,0); content.addView(row,lp)
        }
        content.addView(text("برای حذف یک تراکنش، انگشتت را روی آن نگه دار.",12f,false,muted).apply { setPadding(0,dp(12),0,0) })
    }
    private fun entryDialog(c:Customer,type:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),0,dp(20),0); layoutDirection=View.LAYOUT_DIRECTION_RTL }
        val desc=EditText(this).apply { gravity=Gravity.RIGHT; textDirection=View.TEXT_DIRECTION_RTL; hint=if(type=="sale") "نام کالا / شرح" else "شرح پرداخت (اختیاری)" }
        val amount=EditText(this).apply { inputType=2; gravity=Gravity.RIGHT; hint="مبلغ به تومان" }
        box.addView(desc); box.addView(amount)
        AlertDialog.Builder(this).setTitle(if(type=="sale") "ثبت کالا و مبلغ" else "ثبت دریافت وجه").setView(box)
            .setNegativeButton("انصراف",null).setPositiveButton("ثبت"){_,_->
                val normalizedAmount = amount.text.toString()
                    .replace("۰","0").replace("۱","1").replace("۲","2").replace("۳","3")
                    .replace("۴","4").replace("۵","5").replace("۶","6").replace("۷","7")
                    .replace("۸","8").replace("۹","9").replace("٠","0").replace("١","1")
                    .replace("٢","2").replace("٣","3").replace("٤","4").replace("٥","5")
                    .replace("٦","6").replace("٧","7").replace("٨","8").replace("٩","9")
                    .replace(",","").replace("٬","").replace(" ","").trim()
                val a=normalizedAmount.toLongOrNull()
                if(a==null || a<=0) toast("مبلغ معتبر وارد کن")
                else if(type=="sale" && desc.text.toString().trim().isEmpty()) toast("نام کالا را وارد کن")
                else { db.addEntry(c.id,type,desc.text.toString().trim(),a,Jalali.today()); showCustomer(c) }
            }.show()
    }
    private fun backupMenu() {
        val options=arrayOf("ذخیره فایل پشتیبان (گوشی یا Google Drive)","ارسال فایل پشتیبان با Gmail","بازیابی از فایل پشتیبان")
        AlertDialog.Builder(this).setTitle("پشتیبان‌گیری").setItems(options){_,which->
            when(which){0->createBackup();1->emailBackup();2->restoreBackup()}
        }.show()
    }
    private fun createBackup() {
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="application/json"; putExtra(Intent.EXTRA_TITLE,"daftar-hesab-backup.json")
        }
        startActivityForResult(i,10)
    }
    private fun emailBackup() {
        val file=cacheDir.resolve("daftar-hesab-backup.json")
        file.writeText(db.exportJson(),Charsets.UTF_8)
        val uri=FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val send=Intent(Intent.ACTION_SEND).apply {
            type="application/json"
            putExtra(Intent.EXTRA_SUBJECT,"نسخه پشتیبان دفتر حساب من")
            putExtra(Intent.EXTRA_TEXT, "نسخه پشتیبان دفتر حساب من پیوست شده است.")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send,"ارسال فایل پشتیبان با Gmail یا ایمیل"))
    }
    private fun restoreBackup() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/json" }
        startActivityForResult(i,11)
    }
    @Deprecated("Legacy result API used for broad Android compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data?.data==null) return
        val uri=data.data!!
        try {
            if(requestCode==10) {
                contentResolver.openOutputStream(uri)?.use { it.write(db.exportJson().toByteArray(Charsets.UTF_8)) }
                toast("فایل پشتیبان ذخیره شد")
            } else if(requestCode==11) {
                val json=contentResolver.openInputStream(uri)!!.bufferedReader().use{it.readText()}
                AlertDialog.Builder(this).setMessage("با بازیابی، اطلاعات فعلی جایگزین می‌شود. ادامه می‌دهی؟")
                    .setNegativeButton("انصراف",null).setPositiveButton("بازیابی"){_,_->
                        try { db.importJson(json); showHome(); toast("بازیابی انجام شد") } catch(e:Exception){toast("فایل پشتیبان قابل بازیابی نیست")}
                    }.show()
            }
        } catch(e:Exception){ toast("عملیات انجام نشد: ${e.message}") }
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
